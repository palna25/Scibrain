import pytest
from app.services.graph_engine.schemas import KnowledgeGraph
from app.services.graph_engine.retrieval import retrieve_graph_evidence, EvidenceRetrievalError
from app.services.graph_engine.extraction import extract_graph_candidates, ExtractionError
from app.services.graph_engine.resolution import resolve_entities
from app.services.graph_engine.validation import validate_relationships, RelationshipValidationError
from app.services.graph_engine.finalization import finalize_graph, GraphFinalizationError
from app.services.graph_engine.config import GraphEngineSettings

class Collection:
    def __init__(self, docs): self.docs=docs
    def find_one(self, query): return self.docs.get(query["_id"])

def ev(pid="p1", cid="c1", quote="Graph RAG method"):
    return {"paper_id":pid,"chunk_id":cid,"quote":quote}

def test_retrieval_excludes_unready_and_foreign_chunks():
    collection=Collection({"p1":{"_id":"p1","status":"ready","indexed_chunks":1},"p2":{"_id":"p2","status":"processing","indexed_chunks":1}})
    def search_fn(*,query,paper_ids,limit):
        return [{"id":"c1","paper_id":"p1","chunk_index":0,"text":"Graph RAG method","score":0.8},{"id":"foreign","paper_id":"p2","text":"foreign chunk"}]
    settings=GraphEngineSettings(retrieval_limit=1,max_chunks_per_paper=4,max_total_chunks=4,max_chunks_per_category=1)
    result=retrieve_graph_evidence(["p1","p2"],paper_collection=collection,search_fn=search_fn,settings=settings)
    assert {x["paper_id"] for x in result["chunks"]}=={"p1"}
    assert result["stats"]["rejected_papers"]==[{"paper_id":"p2","reason":"not_ready"}]

def test_extraction_keeps_batch_cross_references_until_all_batches_processed():
    chunks=[{"chunk_id":"c1","paper_id":"p1","text":"Graph RAG method proposes retrieval."},{"chunk_id":"c2","paper_id":"p1","text":"Graph RAG method proposes retrieval."}]
    def gen(prompt):
        if '"chunk_id": "c1"' in prompt:
            return {"entities":[{"name":"Graph RAG","type":"method","evidence":[ev(cid="c1")]},{"name":"retrieval","type":"concept","evidence":[ev(cid="c1",quote="retrieval")] }],"relationships":[{"source":"Graph RAG","target":"retrieval","type":"uses","confidence":0.9,"evidence":[ev(cid="c1",quote="Graph RAG method proposes retrieval.")]}]}
        return {"entities":[{"name":"Graph RAG","type":"method","evidence":[ev(cid="c2")]},{"name":"retrieval","type":"concept","evidence":[ev(cid="c2",quote="retrieval")]}],"relationships":[]}
    result=extract_graph_candidates(chunks,generator=gen,batch_size=1)
    assert len(result["entities"])==2
    assert len(result["relationships"])==1

def test_resolution_drops_edge_that_becomes_self_edge():
    result=resolve_entities([{"entity_id":"a","canonical_name":"Graph RAG","type":"method","evidence":[ev()]},{"entity_id":"b","canonical_name":"graph rag","type":"method","evidence":[ev(cid="c2")]}],[{"source":"a","target":"b","type":"uses","confidence":0.9,"evidence":[ev()]}])
    assert len(result["entities"])==1
    assert result["relationships"]==[]

def test_validation_fails_closed_on_semantic_verifier_error():
    entities=[{"entity_id":"a","paper_ids":["p1"],"evidence":[ev()]},{"entity_id":"b","paper_ids":["p1"],"evidence":[ev()]}]
    rel=[{"source":"a","target":"b","type":"uses","confidence":0.9,"evidence":[ev()]}]
    result=validate_relationships(entities,rel,[{"chunk_id":"c1","paper_id":"p1","text":"Graph RAG method"}],semantic_verifier=lambda *args: (_ for _ in ()).throw(RuntimeError("offline")))
    assert result["relationships"]==[] and len(result["rejected_relationships"])==1

def test_validation_rejects_nan_confidence():
    entities=[{"entity_id":"a","paper_ids":["p1"],"evidence":[ev()]},{"entity_id":"b","paper_ids":["p1"],"evidence":[ev()]}]
    result=validate_relationships(entities,[{"source":"a","target":"b","type":"uses","confidence":float("nan"),"evidence":[ev()]}],[{"chunk_id":"c1","paper_id":"p1","text":"Graph RAG method"}],semantic_verifier=lambda *a:{"supported":True,"direction_correct":True,"confidence":0.99})
    assert not result["relationships"]

def test_finalization_requires_semantic_validation():
    nodes=[{"entity_id":"a","canonical_name":"Graph RAG","type":"method","paper_ids":["p1"],"evidence":[ev()]},{"entity_id":"b","canonical_name":"method","type":"concept","paper_ids":["p1"],"evidence":[ev()]}]
    edges=[{"source":"a","target":"b","type":"uses","confidence":0.9,"evidence":[ev()]}]
    graph=finalize_graph(["p1"],nodes,edges,[{"chunk_id":"c1","paper_id":"p1","text":"Graph RAG method"}])
    assert graph["edges"]==[]

def test_finalization_rejects_unselected_evidence():
    graph=finalize_graph(["p1"],[{"entity_id":"e","canonical_name":"Method","type":"method","paper_ids":["p2"],"evidence":[{"paper_id":"p2","chunk_id":"c2","quote":"Method"}]}],[],[{"chunk_id":"c2","paper_id":"p2","text":"Method"}])
    assert graph["nodes"]==[]

def test_schema_rejects_duplicate_nodes_and_unknown_endpoints():
    with pytest.raises(Exception):
        KnowledgeGraph.model_validate({"graph_id":"g","resource_ids":["p1"],"nodes":[{"entity_id":"a","canonical_name":"x","type":"method"},{"entity_id":"a","canonical_name":"y","type":"method"}]})

def test_finalization_audit_survives_public_schema():
    chunks = [
        {
            "chunk_id": "c1",
            "paper_id": "p1",
            "text": "Graph RAG method uses retrieval.",
        }
    ]

    evidence = [{
        "paper_id": "p1",
        "chunk_id": "c1",
        "quote": "Graph RAG method uses retrieval.",
    }]

    nodes = [
        {
            "entity_id": "a",
            "canonical_name": "Graph RAG",
            "type": "method",
            "paper_ids": ["p1"],
            "evidence": evidence,
        },
        {
            "entity_id": "b",
            "canonical_name": "retrieval",
            "type": "concept",
            "paper_ids": ["p1"],
            "evidence": evidence,
        },
    ]

    # Deliberately omit semantic validation metadata.
    edges = [{
        "source": "a",
        "target": "b",
        "type": "uses",
        "confidence": 0.9,
        "evidence": evidence,
    }]

    raw_graph = finalize_graph(
        ["p1"],
        nodes,
        edges,
        chunks,
    )

    public_graph = KnowledgeGraph.model_validate(raw_graph)

    assert public_graph.edges == []
    assert (
        public_graph.audit.rejected_relationships[0]["reason"]
        == "semantic_validation_missing"
    )
    assert public_graph.quality.rejected_relationships == 1


def test_extraction_preserves_partial_batch_failure_details():
    chunks = [
        {
            "chunk_id": "c1",
            "paper_id": "p1",
            "text": "Graph RAG method.",
        },
        {
            "chunk_id": "c2",
            "paper_id": "p1",
            "text": "Retrieval method.",
        },
    ]

    calls = {"count": 0}

    def generator(prompt):
        calls["count"] += 1

        if calls["count"] == 1:
            raise RuntimeError("simulated batch failure")

        return {"entities": [], "relationships": []}

    result = extract_graph_candidates(
        chunks,
        generator=generator,
        batch_size=1,
    )

    assert result["stats"]["successful_batches"] == 1
    assert result["stats"]["failed_batches"] == 1
    assert len(result["failed_batches"]) == 1
    assert "simulated batch failure" in result["failed_batches"][0]
