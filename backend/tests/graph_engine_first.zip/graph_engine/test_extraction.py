
from app.services.graph_engine.extraction import (ExtractionError, extract_graph_candidates)


def source_chunk(chunk_id="c1", paper_id="p1", text=None):
    return {
        "chunk_id": chunk_id,
        "paper_id": paper_id,
        "title": f"Paper {paper_id}",
        "chunk_index": 0,
        "text": text or (
            "The authors propose GraphNet and evaluate it on DatasetX. "
            "GraphNet improves accuracy on DatasetX."
        ),
        "coverage_categories": ["method", "dataset", "results"],
    }


def test_extracts_entities_with_verified_quotes():
    chunk = source_chunk()

    def fake_generator(prompt):
        return {
            "entities": [
                {
                    "name": "GraphNet",
                    "type": "method",
                    "description": "A proposed method.",
                    "evidence": [
                        {
                            "chunk_id": "c1",
                            "quote": "The authors propose GraphNet",
                        }
                    ],
                }
            ],
            "relationships": [],
        }

    result = extract_graph_candidates([chunk], generate_json_fn=fake_generator)

    assert len(result["entities"]) == 1
    entity = result["entities"][0]
    assert entity["canonical_name"] == "GraphNet"
    assert entity["paper_ids"] == ["p1"]
    assert entity["evidence"][0]["chunk_id"] == "c1"


def test_rejects_fabricated_chunk_ids():
    def fake_generator(prompt):
        return {
            "entities": [
                {
                    "name": "Invented Method",
                    "type": "method",
                    "description": "",
                    "evidence": [
                        {
                            "chunk_id": "not-supplied",
                            "quote": "The authors propose GraphNet",
                        }
                    ],
                }
            ],
            "relationships": [],
        }

    result = extract_graph_candidates(
        [source_chunk()],
        generate_json_fn=fake_generator,
    )

    assert result["entities"] == []
    assert result["stats"]["rejected_entities"] == 1


def test_rejects_quotes_not_found_in_source():
    def fake_generator(prompt):
        return {
            "entities": [
                {
                    "name": "Invented Method",
                    "type": "method",
                    "description": "",
                    "evidence": [
                        {
                            "chunk_id": "c1",
                            "quote": "This claim is not in the paper.",
                        }
                    ],
                }
            ],
            "relationships": [],
        }

    result = extract_graph_candidates(
        [source_chunk()],
        generate_json_fn=fake_generator,
    )

    assert result["entities"] == []


def test_rejects_relationship_with_missing_endpoint():
    def fake_generator(prompt):
        return {
            "entities": [
                {
                    "name": "GraphNet",
                    "type": "method",
                    "description": "",
                    "evidence": [
                        {"chunk_id": "c1", "quote": "propose GraphNet"}
                    ],
                }
            ],
            "relationships": [
                {
                    "source_name": "GraphNet",
                    "source_type": "method",
                    "target_name": "MissingDataset",
                    "target_type": "dataset",
                    "type": "evaluated_on",
                    "description": "evaluated on",
                    "confidence": 0.95,
                    "evidence": [
                        {"chunk_id": "c1", "quote": "evaluate it on DatasetX"}
                    ],
                }
            ],
        }

    result = extract_graph_candidates(
        [source_chunk()],
        generate_json_fn=fake_generator,
    )

    assert result["relationships"] == []
    assert result["stats"]["rejected_relationships"] == 1


def test_accepts_relationship_with_valid_endpoints_and_evidence():
    def fake_generator(prompt):
        return {
            "entities": [
                {
                    "name": "GraphNet",
                    "type": "method",
                    "description": "",
                    "evidence": [
                        {"chunk_id": "c1", "quote": "propose GraphNet"}
                    ],
                },
                {
                    "name": "DatasetX",
                    "type": "dataset",
                    "description": "",
                    "evidence": [
                        {"chunk_id": "c1", "quote": "evaluate it on DatasetX"}
                    ],
                },
            ],
            "relationships": [
                {
                    "source_name": "GraphNet",
                    "source_type": "method",
                    "target_name": "DatasetX",
                    "target_type": "dataset",
                    "type": "evaluated_on",
                    "description": "GraphNet is evaluated on DatasetX.",
                    "confidence": 0.9,
                    "evidence": [
                        {"chunk_id": "c1", "quote": "evaluate it on DatasetX"}
                    ],
                }
            ],
        }

    result = extract_graph_candidates(
        [source_chunk()],
        generate_json_fn=fake_generator,
    )

    assert len(result["entities"]) == 2
    assert len(result["relationships"]) == 1

    relationship = result["relationships"][0]
    entity_ids = {entity["entity_id"] for entity in result["entities"]}
    assert relationship["source_entity_id"] in entity_ids
    assert relationship["target_entity_id"] in entity_ids
    assert relationship["paper_ids"] == ["p1"]


def test_failed_batch_does_not_hide_successful_batch():
    chunks = [
        source_chunk("c1"),
        source_chunk("c2"),
    ]
    calls = {"count": 0}

    def flaky_generator(prompt):
        calls["count"] += 1
        if calls["count"] == 1:
            raise RuntimeError("temporary API error")

        return {
            "entities": [
                {
                    "name": "GraphNet",
                    "type": "method",
                    "description": "",
                    "evidence": [
                        {
                            "chunk_id": "c2",
                            "quote": "The authors propose GraphNet",
                        }
                    ],
                }
            ],
            "relationships": [],
        }

    result = extract_graph_candidates(
        chunks,
        generate_json_fn=flaky_generator,
        max_chunks_per_batch=1,
    )

    assert result["stats"]["failed_batches"] == 1
    assert result["stats"]["processed_batches"] == 1
    assert len(result["entities"]) == 1


def test_deduplicates_repeated_chunks_before_extraction():
    chunk = source_chunk()

    result = extract_graph_candidates(
        [chunk, chunk],
        generate_json_fn=lambda prompt: {
            "entities": [],
            "relationships": [],
        },
    )

    assert result["stats"]["input_chunks"] == 1


def test_empty_input_is_rejected():
    try:
        extract_graph_candidates(
            [],
            generate_json_fn=lambda prompt: {},
        )
        assert False, "Expected empty input to fail"
    except ExtractionError as exc:
        assert "No valid evidence chunks" in str(exc)