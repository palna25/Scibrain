from app.services.graph_engine.orchestrator import (
    PIPELINE_STAGES,
    build_graph_workflow,
    run_graph_workflow,
)


def test_workflow_runs_stages_in_order():
    execution_order = []

    def make_handler(stage_name):
        def handler(state):
            execution_order.append(stage_name)
            return {}

        return handler

    handlers = {
        stage: make_handler(stage)
        for stage in PIPELINE_STAGES
    }

    workflow = build_graph_workflow(handlers)

    result = run_graph_workflow(
        workflow,
        ["paper-1", "paper-2", "paper-1"],
    )

    assert execution_order == list(PIPELINE_STAGES)
    assert result["resource_ids"] == [
        "paper-1",
        "paper-2",
    ]
    assert len(result["stage_events"]) == len(
        PIPELINE_STAGES
    )
    assert result["run_id"]
    assert result["started_at"]
    assert result["completed_at"]


def test_workflow_rejects_missing_handlers():
    try:
        build_graph_workflow({})
    except ValueError as error:
        assert "Missing graph-engine stage handlers" in str(error)
    else:
        raise AssertionError(
            "Expected missing handlers to be rejected."
        )


def test_workflow_rejects_empty_resource_ids():
    handlers = {
        stage: (lambda state: {})
        for stage in PIPELINE_STAGES
    }

    workflow = build_graph_workflow(handlers)

    try:
        run_graph_workflow(workflow, ["", "  "])
    except ValueError as error:
        assert "resource ID" in str(error)
    else:
        raise AssertionError(
            "Expected empty resource IDs to be rejected."
        )