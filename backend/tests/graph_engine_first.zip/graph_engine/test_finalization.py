
import pytest

from app.services.graph_engine.finalization import (
    GraphFinalizationError,
    finalize_graph,
)


def make_chunk(paper_id="p1", chunk_id="c1"):
    return {
        "paper_id": paper_id,
        "chunk_id": chunk_id,
        "chunk_index": 0,
        "text": "GraphNet uses DatasetX for evaluation.",
    }


def make_entity(entity_id, name, paper_id="p1", chunk_id="c1"):
    return {
        "entity_id": entity_id,
        "canonical_name": name,
        "entity_type": "method" if name == "GraphNet" else "dataset",
        "description": "",
        "aliases": [],
        "paper_ids": [paper_id],
        "evidence": [
            {
                "paper_id": paper_id,
                "chunk_id": chunk_id,
                "quote": "GraphNet uses DatasetX for evaluation.",
            }
        ],
        "properties": {},
    }


def make_edge(source="e1", target="e2", paper_id="p1", chunk_id="c1"):
    return {
        "relationship_id": "r1",
        "source_entity_id": source,
        "target_entity_id": target,
        "relation_type": "evaluated_on",
        "description": "GraphNet uses DatasetX for evaluation.",
        "confidence": 0.9,
        "paper_ids": [paper_id],
        "evidence": [
            {
                "paper_id": paper_id,
                "chunk_id": chunk_id,
                "quote": "GraphNet uses DatasetX for evaluation.",
            }
        ],
        "validation": {
            "status": "accepted",
            "semantic_support": True,
            "direction_correct": True,
            "semantic_confidence": 0.9,
            "reason": "The passage explicitly supports this relation.",
            "validator": "test_verifier",
        },
        "properties": {},
    }


def test_valid_graph_is_constructed():
    result = finalize_graph(
        ["p1"],
        [make_entity("e1", "GraphNet"), make_entity("e2", "DatasetX")],
        [make_edge()],
        [make_chunk()],
    )

    assert len(result["nodes"]) == 2
    assert len(result["edges"]) == 1
    assert result["quality"]["nodes"] == 2
    assert result["quality"]["edges"] == 1
    assert result["edges"][0]["source_entity_id"] in {
        node["entity_id"] for node in result["nodes"]
    }


def test_duplicate_relationships_are_merged():
    result = finalize_graph(
        ["p1"],
        [make_entity("e1", "GraphNet"), make_entity("e2", "DatasetX")],
        [make_edge(), {**make_edge(), "relationship_id": "r2"}],
        [make_chunk()],
    )

    assert len(result["edges"]) == 1
    assert len(result["edges"][0]["evidence"]) == 1


def test_duplicate_node_ids_merge_evidence():
    first = make_entity("e1", "GraphNet")
    second = make_entity("e1", "GraphNet")
    second["evidence"] = [{
        "paper_id": "p1",
        "chunk_id": "c2",
        "quote": "GraphNet uses DatasetX for evaluation.",
    }]

    result = finalize_graph(
        ["p1"],
        [first, second, make_entity("e2", "DatasetX")],
        [],
        [make_chunk(), make_chunk(chunk_id="c2")],
    )

    node = next(item for item in result["nodes"] if item["entity_id"] == "e1")
    assert len(node["evidence"]) == 2
    assert result["quality"]["duplicate_nodes_merged"] == 1


def test_node_with_fabricated_quote_is_rejected():
    entity = make_entity("e1", "GraphNet")
    entity["evidence"][0]["quote"] = "This text does not exist."

    result = finalize_graph(
        ["p1"],
        [entity, make_entity("e2", "DatasetX")],
        [],
        [make_chunk()],
    )

    assert "e1" not in {node["entity_id"] for node in result["nodes"]}
    assert result["quality"]["rejected_nodes"] == 1


def test_edge_with_missing_endpoint_is_rejected():
    result = finalize_graph(
        ["p1"],
        [make_entity("e1", "GraphNet"), make_entity("e2", "DatasetX")],
        [make_edge(source="missing")],
        [make_chunk()],
    )

    assert result["edges"] == []
    assert result["quality"]["rejected_relationships"] == 1


def test_edge_without_semantic_approval_is_rejected():
    edge = make_edge()
    edge.pop("validation")

    result = finalize_graph(
        ["p1"],
        [make_entity("e1", "GraphNet"), make_entity("e2", "DatasetX")],
        [edge],
        [make_chunk()],
    )

    assert result["edges"] == []
    assert result["audit"]["rejected_relationships"][0]["reason"] == (
        "relationship_missing_semantic_acceptance_record"
    )


def test_edge_with_fabricated_quote_is_rejected():
    edge = make_edge()
    edge["evidence"][0]["quote"] = "A fabricated claim."

    result = finalize_graph(
        ["p1"],
        [make_entity("e1", "GraphNet"), make_entity("e2", "DatasetX")],
        [edge],
        [make_chunk()],
    )

    assert result["edges"] == []
    assert result["audit"]["rejected_relationships"][0]["reason"] == (
        "evidence_quote_not_found_in_source"
    )


def test_evidence_from_unselected_paper_is_rejected():
    result = finalize_graph(
        ["p1"],
        [make_entity("e1", "GraphNet", paper_id="p2")],
        [],
        [make_chunk(paper_id="p2")],
    )

    assert result["nodes"] == []
    assert result["quality"]["rejected_nodes"] == 1


def test_edge_evidence_must_support_both_endpoints_in_same_paper():
    entities = [
        make_entity("e1", "GraphNet", paper_id="p1", chunk_id="c1"),
        make_entity("e2", "DatasetX", paper_id="p2", chunk_id="c2"),
    ]

    result = finalize_graph(
        ["p1", "p2"],
        entities,
        [make_edge(paper_id="p1", chunk_id="c1")],
        [make_chunk("p1", "c1"), make_chunk("p2", "c2")],
    )

    assert result["edges"] == []
    assert result["audit"]["rejected_relationships"][0]["reason"] == (
        "no_shared_supporting_paper"
    )


def test_conflicting_chunk_ids_raise_error():
    chunks = [
        make_chunk(),
        {
            **make_chunk(),
            "text": "Different content under the same chunk ID.",
        },
    ]

    with pytest.raises(GraphFinalizationError):
        finalize_graph(["p1"], [], [], chunks)


def test_empty_resource_ids_are_rejected():
    with pytest.raises(GraphFinalizationError):
        finalize_graph([], [], [], [])


def test_isolated_nodes_are_counted():
    result = finalize_graph(
        ["p1"],
        [make_entity("e1", "GraphNet"), make_entity("e2", "DatasetX")],
        [],
        [make_chunk()],
    )

    assert result["quality"]["isolated_nodes"] == 2


def test_graph_id_is_deterministic_for_same_selected_papers():
    args = (
        ["p1", "p2"],
        [],
        [],
        [],
    )

    first = finalize_graph(*args)
    second = finalize_graph(["p2", "p1"], [], [], [])

    assert first["graph_id"] == second["graph_id"]
