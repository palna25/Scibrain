
import pytest

from app.services.graph_engine.validation import (
    RelationshipValidationError,
    validate_relationships,
)


def make_chunk(paper_id="p1", chunk_id="c1"):
    return {
        "paper_id": paper_id,
        "chunk_id": chunk_id,
        "chunk_index": 0,
        "text": (
            "GraphNet uses DatasetX for evaluation. "
            "The paper reports that GraphNet improves accuracy."
        ),
    }


def make_entity(entity_id, name, paper_id="p1", chunk_id="c1"):
    quote = (
        "GraphNet uses DatasetX for evaluation."
        if name in {"GraphNet", "DatasetX"}
        else "The paper reports that GraphNet improves accuracy."
    )
    return {
        "entity_id": entity_id,
        "canonical_name": name,
        "entity_type": "method" if name == "GraphNet" else "dataset",
        "description": "",
        "aliases": [],
        "paper_ids": [paper_id],
        "evidence": [
            {
                "paper_id": paper_id,
                "chunk_id": chunk_id,
                "quote": quote,
            }
        ],
        "properties": {},
    }


def make_relationship(source="e1", target="e2", paper_id="p1", chunk_id="c1"):
    return {
        "relationship_id": "r1",
        "source_entity_id": source,
        "target_entity_id": target,
        "relation_type": "evaluated_on",
        "description": "GraphNet is evaluated on DatasetX.",
        "confidence": 0.95,
        "paper_ids": [paper_id],
        "evidence": [
            {
                "paper_id": paper_id,
                "chunk_id": chunk_id,
                "quote": "GraphNet uses DatasetX for evaluation.",
            }
        ],
        "properties": {},
    }


def supporting_verifier(_payload):
    return {
        "supported": True,
        "direction_correct": True,
        "confidence": 0.93,
        "reason": "The passage explicitly states that GraphNet uses DatasetX.",
    }


def test_valid_relationship_is_accepted():
    result = validate_relationships(
        [make_entity("e1", "GraphNet"), make_entity("e2", "DatasetX")],
        [make_relationship()],
        [make_chunk()],
        verify_fn=supporting_verifier,
    )

    assert len(result["relationships"]) == 1
    assert result["rejected_relationships"] == []
    assert result["relationships"][0]["validation"]["status"] == "accepted"
    assert result["relationships"][0]["confidence"] == pytest.approx(0.93)


def test_fabricated_evidence_quote_is_rejected_before_verification():
    relationship = make_relationship()
    relationship["evidence"][0]["quote"] = "GraphNet outperforms every model."

    result = validate_relationships(
        [make_entity("e1", "GraphNet"), make_entity("e2", "DatasetX")],
        [relationship],
        [make_chunk()],
        verify_fn=supporting_verifier,
    )

    assert result["relationships"] == []
    assert result["rejected_relationships"][0]["reason"] == (
        "evidence_quote_not_found_in_source"
    )


def test_semantically_unsupported_relationship_is_rejected():
    def verifier(_payload):
        return {
            "supported": False,
            "direction_correct": True,
            "confidence": 0.95,
            "reason": "The passage does not support the claimed relation.",
        }

    result = validate_relationships(
        [make_entity("e1", "GraphNet"), make_entity("e2", "DatasetX")],
        [make_relationship()],
        [make_chunk()],
        verify_fn=verifier,
    )

    assert result["relationships"] == []
    assert result["rejected_relationships"][0]["reason"] == (
        "semantic_support_not_established"
    )


def test_reversed_relationship_is_rejected():
    def verifier(_payload):
        return {
            "supported": True,
            "direction_correct": False,
            "confidence": 0.95,
            "reason": "The direction is not supported.",
        }

    result = validate_relationships(
        [make_entity("e1", "GraphNet"), make_entity("e2", "DatasetX")],
        [make_relationship()],
        [make_chunk()],
        verify_fn=verifier,
    )

    assert result["relationships"] == []
    assert result["rejected_relationships"][0]["reason"] == (
        "relationship_direction_not_supported"
    )


def test_low_semantic_confidence_is_rejected():
    def verifier(_payload):
        return {
            "supported": True,
            "direction_correct": True,
            "confidence": 0.40,
            "reason": "The evidence is ambiguous.",
        }

    result = validate_relationships(
        [make_entity("e1", "GraphNet"), make_entity("e2", "DatasetX")],
        [make_relationship()],
        [make_chunk()],
        verify_fn=verifier,
        min_confidence=0.70,
    )

    assert result["relationships"] == []
    assert result["rejected_relationships"][0]["reason"] == (
        "semantic_confidence_below_threshold"
    )


def test_missing_endpoint_is_rejected():
    result = validate_relationships(
        [make_entity("e1", "GraphNet")],
        [make_relationship(target="missing")],
        [make_chunk()],
        verify_fn=supporting_verifier,
    )

    assert result["relationships"] == []
    assert result["rejected_relationships"][0]["reason"] == (
        "relationship_endpoint_not_grounded"
    )


def test_entity_without_valid_evidence_cannot_support_an_edge():
    entity = make_entity("e1", "GraphNet")
    entity["evidence"][0]["quote"] = "This sentence is not in the paper."

    result = validate_relationships(
        [entity, make_entity("e2", "DatasetX")],
        [make_relationship()],
        [make_chunk()],
        verify_fn=supporting_verifier,
    )

    assert result["relationships"] == []
    assert result["rejected_relationships"][0]["reason"] == (
        "relationship_endpoint_not_grounded"
    )


def test_cross_paper_edge_without_shared_endpoint_ownership_is_rejected():
    entities = [
        make_entity("e1", "GraphNet", paper_id="p1", chunk_id="c1"),
        make_entity("e2", "DatasetX", paper_id="p2", chunk_id="c2"),
    ]
    chunks = [
        make_chunk("p1", "c1"),
        make_chunk("p2", "c2"),
    ]
    relationship = make_relationship(
        paper_id="p1",
        chunk_id="c1",
    )

    result = validate_relationships(
        entities,
        [relationship],
        chunks,
        verify_fn=supporting_verifier,
    )

    assert result["relationships"] == []
    assert result["rejected_relationships"][0]["reason"] == (
        "no_shared_supporting_paper"
    )


def test_verifier_failure_fails_closed_by_default():
    def failing_verifier(_payload):
        raise RuntimeError("Simulated provider failure")

    with pytest.raises(RelationshipValidationError):
        validate_relationships(
            [make_entity("e1", "GraphNet"), make_entity("e2", "DatasetX")],
            [make_relationship()],
            [make_chunk()],
            verify_fn=failing_verifier,
        )


def test_duplicate_chunk_ids_with_conflicting_content_raise_error():
    chunks = [
        make_chunk(),
        {
            **make_chunk(),
            "text": "Different source content under the same chunk ID.",
        },
    ]

    with pytest.raises(RelationshipValidationError):
        validate_relationships(
            [make_entity("e1", "GraphNet"), make_entity("e2", "DatasetX")],
            [make_relationship()],
            chunks,
            verify_fn=supporting_verifier,
        )


def test_invalid_confidence_threshold_is_rejected():
    with pytest.raises(ValueError):
        validate_relationships(
            [],
            [],
            [],
            min_confidence=1.5,
            verify_fn=supporting_verifier,
        )
