
from __future__ import annotations

from app.services.graph_engine.retrieval import (
    EvidenceRetrievalError,
    RetrievalSettings,
    retrieve_graph_evidence,
)


class FakeCollection:
    def __init__(self, papers):
        self.papers = papers

    def find(self, query):
        requested = set(query["_id"]["$in"])
        return [paper for paper in self.papers if paper["_id"] in requested]


def make_paper(paper_id="p1", status="ready", indexed_chunks=10):
    return {
        "_id": paper_id,
        "title": f"Paper {paper_id}",
        "filename": f"{paper_id}.pdf",
        "status": status,
        "indexed_chunks": indexed_chunks,
    }


def make_search_fn(chunks=None, errors=None):
    chunks = chunks or []
    errors = errors or {}

    def search_fn(query, paper_ids, limit):
        category = next(
            (
                word
                for word in (
                    "problem", "contributions", "methods", "datasets",
                    "evaluated", "metrics", "results", "compared",
                    "limitations", "future work", "concepts", "conclusions",
                )
                if word in query.lower()
            ),
            None,
        )
        if category in errors:
            raise RuntimeError(errors[category])

        # Return only the requested paper's evidence, as Qdrant should.
        return [
            chunk for chunk in chunks
            if chunk.get("paper_id") in paper_ids
        ]

    return search_fn


def test_retrieval_requires_resource_ids():
    try:
        retrieve_graph_evidence(
            [],
            paper_collection=FakeCollection([]),
            search_fn=make_search_fn(),
        )
        assert False, "Expected empty IDs to be rejected"
    except EvidenceRetrievalError as exc:
        assert "resource ID" in str(exc)


def test_missing_paper_is_reported():
    try:
        retrieve_graph_evidence(
            ["missing"],
            paper_collection=FakeCollection([]),
            search_fn=make_search_fn(),
        )
        assert False, "Expected unavailable papers to be rejected"
    except EvidenceRetrievalError as exc:
        assert exc.details["rejected_papers"][0]["reason"] == "paper_not_found"


def test_unready_paper_is_not_searched():
    calls = []

    def search_fn(**kwargs):
        calls.append(kwargs)
        return []

    try:
        retrieve_graph_evidence(
            ["p1"],
            paper_collection=FakeCollection([make_paper(status="error")]),
            search_fn=search_fn,
        )
        assert False, "Expected unready paper to be rejected"
    except EvidenceRetrievalError as exc:
        assert exc.details["rejected_papers"][0]["reason"] == "paper_status_error"

    assert calls == []


def test_unindexed_paper_is_not_searched():
    calls = []

    def search_fn(**kwargs):
        calls.append(kwargs)
        return []

    try:
        retrieve_graph_evidence(
            ["p1"],
            paper_collection=FakeCollection([make_paper(indexed_chunks=0)]),
            search_fn=search_fn,
        )
        assert False, "Expected unindexed paper to be rejected"
    except EvidenceRetrievalError as exc:
        assert exc.details["rejected_papers"][0]["reason"] == "paper_has_no_indexed_chunks"

    assert calls == []



def test_chunks_from_another_paper_are_rejected():
    foreign_chunk = {
        "id": "chunk-foreign",
        "paper_id": "p2",
        "chunk_index": 0,
        "text": "This text belongs to a different paper.",
        "score": 0.99,
    }

    # Deliberately simulate a faulty backend that ignores paper_ids.
    def faulty_search_fn(query, paper_ids, limit):
        return [foreign_chunk]

    result = retrieve_graph_evidence(
        ["p1"],
        paper_collection=FakeCollection([make_paper("p1")]),
        search_fn=faulty_search_fn,
    )

    assert result["chunks"] == []
    assert result["stats"]["rejected_chunk_results"] > 0


def test_duplicate_chunks_are_merged():
    chunks = [
        {
            "id": "same-chunk",
            "paper_id": "p1",
            "chunk_index": 2,
            "title": "Paper p1",
            "text": "The method was evaluated on a benchmark dataset.",
            "score": 0.6,
        },
        {
            "id": "same-chunk",
            "paper_id": "p1",
            "chunk_index": 2,
            "title": "Paper p1",
            "text": "The method was evaluated on a benchmark dataset.",
            "score": 0.9,
        },
    ]

    result = retrieve_graph_evidence(
        ["p1"],
        paper_collection=FakeCollection([make_paper("p1")]),
        search_fn=make_search_fn(chunks),
    )

    assert len(result["chunks"]) == 1
    assert result["chunks"][0]["score"] == 0.9


def test_chunk_provenance_is_preserved():
    chunks = [
        {
            "id": "chunk-1",
            "paper_id": "p1",
            "chunk_index": 4,
            "title": "Paper p1",
            "text": "The study reports its evaluation results.",
            "score": 0.8,
        }
    ]

    result = retrieve_graph_evidence(
        ["p1"],
        paper_collection=FakeCollection([make_paper("p1")]),
        search_fn=make_search_fn(chunks),
    )

    chunk = result["chunks"][0]
    assert chunk["paper_id"] == "p1"
    assert chunk["qdrant_id"] == "chunk-1"
    assert chunk["chunk_index"] == 4
    assert chunk["retrieval_queries"]
    assert chunk["coverage_categories"]


def test_query_failures_are_reported():
    def search_fn(**kwargs):
        raise RuntimeError("embedding service unavailable")

    try:
        retrieve_graph_evidence(
            ["p1"],
            paper_collection=FakeCollection([make_paper("p1")]),
            search_fn=search_fn,
        )
        assert False, "Expected total retrieval failure"
    except EvidenceRetrievalError as exc:
        assert "All Qdrant retrieval queries failed" in str(exc)
        assert exc.details["query_failures"]


def test_total_chunk_limit_is_respected():
    chunks = [
        {
            "id": f"chunk-{i}",
            "paper_id": "p1",
            "chunk_index": i,
            "text": f"Distinct evidence passage number {i}.",
            "score": 1.0 - (i * 0.01),
        }
        for i in range(20)
    ]

    result = retrieve_graph_evidence(
        ["p1"],
        paper_collection=FakeCollection([make_paper("p1")]),
        search_fn=make_search_fn(chunks),
        settings=RetrievalSettings(
            query_limit=5,
            max_chunks_per_paper=20,
            max_total_chunks=4,
            max_chunks_per_category=3,
        ),
    )

    assert len(result["chunks"]) <= 4
