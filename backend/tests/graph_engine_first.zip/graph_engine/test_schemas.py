import pytest
from pydantic import ValidationError

from app.services.graph_engine.schemas import (
    EntityType,
    EvidenceReference,
    GraphEntity,
    GraphRelationship,
    KnowledgeGraph,
    RelationType,
)


def make_evidence(
    paper_id: str = "paper-1",
) -> EvidenceReference:
    return EvidenceReference(
        paper_id=paper_id,
        quote="The proposed method improves classification accuracy.",
        chunk_id="chunk-1",
        chunk_index=0,
    )


def make_entity(
    entity_id: str,
    name: str,
) -> GraphEntity:
    return GraphEntity(
        entity_id=entity_id,
        canonical_name=name,
        entity_type=EntityType.METHOD,
        paper_ids=["paper-1"],
        evidence=[make_evidence()],
    )


def test_entity_retains_source_evidence():
    entity = make_entity(
        "entity-method-1",
        "Proposed Method",
    )

    assert entity.canonical_name == "Proposed Method"
    assert entity.paper_ids == ["paper-1"]
    assert entity.evidence[0].paper_id == "paper-1"


def test_entity_rejects_evidence_from_unowned_paper():
    with pytest.raises(ValidationError):
        GraphEntity(
            entity_id="entity-method-1",
            canonical_name="Proposed Method",
            entity_type=EntityType.METHOD,
            paper_ids=["paper-1"],
            evidence=[make_evidence("paper-2")],
        )


def test_relationship_requires_evidence():
    with pytest.raises(ValidationError):
        GraphRelationship(
            relationship_id="relationship-1",
            source_entity_id="entity-1",
            target_entity_id="entity-2",
            relation_type=RelationType.USES,
            confidence=0.9,
            evidence=[],
        )


def test_graph_rejects_unknown_edge_endpoint():
    source = make_entity("entity-1", "Method A")

    relationship = GraphRelationship(
        relationship_id="relationship-1",
        source_entity_id="entity-1",
        target_entity_id="entity-missing",
        relation_type=RelationType.USES,
        confidence=0.9,
        evidence=[make_evidence()],
    )

    with pytest.raises(ValidationError):
        KnowledgeGraph(
            graph_id="graph-test",
            resource_ids=["paper-1"],
            nodes=[source],
            edges=[relationship],
        )


def test_graph_accepts_valid_directed_relationship():
    method = make_entity("entity-1", "Method A")

    dataset = GraphEntity(
        entity_id="entity-2",
        canonical_name="Dataset B",
        entity_type=EntityType.DATASET,
        paper_ids=["paper-1"],
        evidence=[make_evidence()],
    )

    relationship = GraphRelationship(
        relationship_id="relationship-1",
        source_entity_id="entity-1",
        target_entity_id="entity-2",
        relation_type=RelationType.EVALUATED_ON,
        confidence=0.95,
        evidence=[make_evidence()],
    )

    graph = KnowledgeGraph(
        graph_id="graph-test",
        resource_ids=["paper-1"],
        nodes=[method, dataset],
        edges=[relationship],
    )

    assert len(graph.nodes) == 2
    assert len(graph.edges) == 1
    assert graph.edges[0].source_entity_id == "entity-1"
    assert graph.edges[0].target_entity_id == "entity-2"


def test_graph_rejects_duplicate_entity_ids():
    first = make_entity("entity-1", "Method A")
    second = make_entity("entity-1", "Method B")

    with pytest.raises(ValidationError):
        KnowledgeGraph(
            graph_id="graph-test",
            resource_ids=["paper-1"],
            nodes=[first, second],
        )