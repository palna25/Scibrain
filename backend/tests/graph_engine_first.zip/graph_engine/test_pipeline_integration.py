
from __future__ import annotations

from typing import Any

import pytest

from app.services.graph_engine.orchestrator import (
    build_default_handlers,
    build_graph_workflow,
    run_graph_workflow,
)


PAPER_ID = "paper-1"
CHUNK_ID = "chunk-1"

CHUNK_TEXT = (
    "The researchers propose GraphMethod for document classification. "
    "GraphMethod uses DatasetAlpha to evaluate classification accuracy."
)


def evidence_chunk() -> dict[str, Any]:
    return {
        "chunk_id": CHUNK_ID,
        "paper_id": PAPER_ID,
        "chunk_index": 0,
        "title": "A Sample Research Paper",
        "text": CHUNK_TEXT,
        "score": 0.95,
        "categories": ["method", "dataset", "evaluation"],
        "queries": ["method", "dataset", "evaluation"],
    }


def entity(
    entity_id: str,
    name: str,
    entity_type: str,
) -> dict[str, Any]:
    return {
        "entity_id": entity_id,
        "canonical_name": name,
        "entity_type": entity_type,
        "description": "",
        "aliases": [],
        "paper_ids": [PAPER_ID],
        "evidence": [
            {
                "paper_id": PAPER_ID,
                "quote": name,
                "chunk_id": CHUNK_ID,
                "chunk_index": 0,
            }
        ],
        "properties": {},
    }


def relationship() -> dict[str, Any]:
    return {
        "relationship_id": "rel-1",
        "source_entity_id": "ent-method",
        "target_entity_id": "ent-dataset",
        "relation_type": "evaluated_on",
        "description": "GraphMethod is evaluated using DatasetAlpha.",
        "evidence": [
            {
                "paper_id": PAPER_ID,
                "quote": (
                    "GraphMethod uses DatasetAlpha to evaluate "
                    "classification accuracy."
                ),
                "chunk_id": CHUNK_ID,
                "chunk_index": 0,
            }
        ],
        "confidence": 0.95,
        "paper_ids": [PAPER_ID],
        "properties": {},
    }


def make_pipeline(
    *,
    chunks: list[dict[str, Any]] | None = None,
    entities: list[dict[str, Any]] | None = None,
    relationships: list[dict[str, Any]] | None = None,
    verify_fn=None,
):
    """Build the production workflow with external calls mocked."""
    chunks = [evidence_chunk()] if chunks is None else chunks
    entities = (
        [
            entity("ent-method", "GraphMethod", "method"),
            entity("ent-dataset", "DatasetAlpha", "dataset"),
        ]
        if entities is None
        else entities
    )
    relationships = (
        [relationship()] if relationships is None else relationships
    )

    def retrieve_fn(resource_ids):
        return {
            "resource_ids": resource_ids,
            "papers": [
                {
                    "paper_id": PAPER_ID,
                    "title": "A Sample Research Paper",
                    "status": "ready",
                    "indexed_chunks": 1,
                }
            ],
            "rejected_papers": [],
            "chunks": chunks,
            "stats": {
                "requested_papers": len(resource_ids),
                "eligible_papers": 1,
                "selected_chunks": len(chunks),
            },
            "warnings": [],
        }

    def extract_fn(retrieved_chunks):
        return {
            "entities": entities,
            "relationships": relationships,
            "stats": {
                "candidate_entities": len(entities),
                "candidate_relationships": len(relationships),
            },
            "failed_batches": [],
        }

    def resolve_fn(candidate_entities, candidate_relationships):
        # Deliberately simple deterministic fake. The actual resolver
        # is covered by its existing unit tests.
        return {
            "entities": candidate_entities,
            "relationships": candidate_relationships,
            "id_mapping": {},
            "stats": {
                "input_entities": len(candidate_entities),
                "resolved_entities": len(candidate_entities),
                "rejected_entities": 0,
            },
        }

    def validate_fn(
        candidate_entities,
        candidate_relationships,
        source_chunks,
        **kwargs,
    ):
        # Simulate semantic validation without contacting Gemini.
        accepted = []
        rejected = []

        for edge in candidate_relationships:
            if edge.get("properties", {}).get("force_reject"):
                rejected.append({
                    "relationship": edge,
                    "reason": "test_rejection",
                })
            else:
                accepted.append({
                    **edge,
                    "validation": {
                        "status": "accepted",
                        "semantic_support": True,
                        "direction_correct": True,
                        "semantic_confidence": 0.95,
                        "reason": "Supported by test fixture.",
                        "validator": "test_verifier",
                    },
                })

        return {
            "relationships": accepted,
            "rejected_relationships": rejected,
            "stats": {
                "accepted_relationships": len(accepted),
                "rejected_relationships": len(rejected),
            },
        }

    handlers = build_default_handlers(
        retrieve_fn=retrieve_fn,
        extract_fn=extract_fn,
        resolve_fn=resolve_fn,
        validate_fn=validate_fn,
        verify_fn=verify_fn,
    )

    return build_graph_workflow(handlers)


def test_complete_pipeline_builds_schema_valid_graph():
    workflow = make_pipeline()

    result = run_graph_workflow(workflow, [PAPER_ID])

    assert result["final_graph_valid"] is True
    assert len(result["nodes"]) == 2
    assert len(result["edges"]) == 1
    assert result["quality"]["accepted_entities"] == 2
    assert result["quality"]["accepted_relationships"] == 1

    assert result["edges"][0]["source_entity_id"] in {
        node["entity_id"] for node in result["nodes"]
    }
    assert result["edges"][0]["target_entity_id"] in {
        node["entity_id"] for node in result["nodes"]
    }

    assert all(
        evidence["paper_id"] in result["resource_ids"]
        for node in result["nodes"]
        for evidence in node["evidence"]
    )
    assert all(
        evidence["paper_id"] in result["resource_ids"]
        for edge in result["edges"]
        for evidence in edge["evidence"]
    )


def test_pipeline_supports_empty_extraction_results():
    workflow = make_pipeline(entities=[], relationships=[])

    result = run_graph_workflow(workflow, [PAPER_ID])

    assert result["final_graph_valid"] is True
    assert result["nodes"] == []
    assert result["edges"] == []
    assert result["quality"]["accepted_entities"] == 0
    assert result["quality"]["accepted_relationships"] == 0


def test_pipeline_deduplicates_selected_resource_ids():
    workflow = make_pipeline()

    result = run_graph_workflow(
        workflow,
        [PAPER_ID, PAPER_ID, "paper-2", "paper-2"],
    )

    assert result["resource_ids"] == [PAPER_ID, "paper-2"]


def test_pipeline_rejects_evidence_from_unselected_paper():
    bad_chunk = evidence_chunk()
    bad_chunk["paper_id"] = "unselected-paper"

    workflow = make_pipeline(chunks=[bad_chunk])

    with pytest.raises(RuntimeError, match="retrieve_evidence"):
        run_graph_workflow(workflow, [PAPER_ID])


def test_pipeline_records_all_stage_events():
    workflow = make_pipeline()

    result = run_graph_workflow(workflow, [PAPER_ID])

    expected_stages = [
        "retrieve_evidence",
        "extract_entities",
        "resolve_entities",
        "discover_relationships",
        "validate_evidence",
        "build_graph",
        "check_quality",
    ]

    assert [event["stage"] for event in result["stage_events"]] == (
        expected_stages
    )
    assert all(
        event["status"] == "completed"
        for event in result["stage_events"]
    )


def test_pipeline_marks_cross_paper_discovery_disabled():
    workflow = make_pipeline()

    result = run_graph_workflow(workflow, [PAPER_ID])

    assert result["cross_paper_discovery"]["enabled"] is False
    assert result["metadata"]["cross_paper_discovery_enabled"] is False
