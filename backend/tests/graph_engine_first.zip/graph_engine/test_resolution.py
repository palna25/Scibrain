
from app.services.graph_engine.resolution import resolve_entities


def make_entity(entity_id, name, paper_id="p1", entity_type="method"):
    return {
        "entity_id": entity_id,
        "canonical_name": name,
        "entity_type": entity_type,
        "description": f"Description of {name}",
        "aliases": [],
        "paper_ids": [paper_id],
        "evidence": [
            {
                "paper_id": paper_id,
                "chunk_id": f"{paper_id}-chunk-1",
                "quote": f"The paper proposes {name}.",
            }
        ],
        "properties": {},
    }


def make_relationship(source_id, target_id, paper_id="p1"):
    return {
        "relationship_id": "old-edge",
        "source_entity_id": source_id,
        "target_entity_id": target_id,
        "relation_type": "uses",
        "description": "The method uses the component.",
        "confidence": 0.9,
        "paper_ids": [paper_id],
        "evidence": [
            {
                "paper_id": paper_id,
                "chunk_id": f"{paper_id}-chunk-1",
                "quote": "The paper proposes MethodX and uses ComponentY.",
            }
        ],
        "properties": {},
    }


def test_exact_duplicate_entities_are_merged():
    entities = [
        make_entity("e1", "GraphNet", "p1"),
        make_entity("e2", " graphnet ", "p2"),
    ]

    result = resolve_entities(entities)

    assert len(result["entities"]) == 1
    entity = result["entities"][0]
    assert set(entity["paper_ids"]) == {"p1", "p2"}
    assert len(entity["evidence"]) == 2
    assert result["stats"]["merged_entities"] == 1


def test_different_entity_types_are_not_merged():
    entities = [
        make_entity("e1", "GraphNet", entity_type="method"),
        make_entity("e2", "GraphNet", entity_type="dataset"),
    ]

    result = resolve_entities(entities)

    assert len(result["entities"]) == 2


def test_similar_but_nonidentical_names_are_not_fuzzy_merged():
    entities = [
        make_entity("e1", "GraphNet"),
        make_entity("e2", "GraphNet Plus"),
    ]

    result = resolve_entities(entities)

    assert len(result["entities"]) == 2


def test_generic_names_from_different_papers_remain_separate():
    entities = [
        make_entity("e1", "Proposed Method", "p1"),
        make_entity("e2", "Proposed Method", "p2"),
    ]

    result = resolve_entities(entities)

    assert len(result["entities"]) == 2


def test_relationship_endpoints_are_remapped():
    entities = [
        make_entity("method-old", "GraphNet"),
        make_entity("method-duplicate", " graphnet "),
        make_entity("dataset", "DatasetX", entity_type="dataset"),
    ]

    relationship = make_relationship("method-duplicate", "dataset")

    result = resolve_entities(entities, [relationship])

    assert len(result["entities"]) == 2
    assert len(result["relationships"]) == 1

    edge = result["relationships"][0]
    valid_ids = {entity["entity_id"] for entity in result["entities"]}

    assert edge["source_entity_id"] in valid_ids
    assert edge["target_entity_id"] in valid_ids
    assert edge["source_entity_id"] != "method-duplicate"
    assert edge["relationship_id"].startswith("rel_")


def test_relationship_with_missing_endpoint_is_rejected():
    entities = [make_entity("e1", "GraphNet")]
    relationship = make_relationship("e1", "missing")

    result = resolve_entities(entities, [relationship])

    assert result["relationships"] == []
    assert result["stats"]["rejected_relationships"] == 1


def test_entity_without_evidence_is_rejected():
    entity = make_entity("e1", "GraphNet")
    entity["evidence"] = []

    result = resolve_entities([entity])

    assert result["entities"] == []
    assert result["stats"]["rejected_entities"] == 1


def test_input_statistics_are_correct():
    entities = [
        make_entity("e1", "GraphNet"),
        make_entity("e2", "DatasetX", entity_type="dataset"),
    ]

    result = resolve_entities(iter(entities), iter([]))

    assert result["stats"]["input_entities"] == 2
    assert result["stats"]["input_relationships"] == 0
